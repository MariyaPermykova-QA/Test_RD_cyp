describe('Test_RS', () => {
    beforeEach(() => {
    cy.visit('http://russian-houses.k8s-dev.goswebcms.ru/')  // Заходим на сайт РД
 })

    it('Change language to English', () => {  // сменить язык на английский
    cy.get('#languageSwitcher').click(); // Нажимаем на иконку смены языка
    cy.get('#languageSwitcher > .wpml-ls-statics-shortcode_actions > ul > .wpml-ls-item-en > .wpml-ls-link > .wpml-ls-display').contains('Английский').click(); // Выбрать Английский из раскрывающегося списка
    cy.get('#languageSwitcher > [href="#"]').should('contain', 'En'); // проверка что язык поменялся
  });

    it('Change language to Armenian', () => {
    cy.get('#languageSwitcher').click();
    cy.get('#languageSwitcher > .wpml-ls-statics-shortcode_actions > ul > .wpml-ls-item-hy > .wpml-ls-link > .wpml-ls-display').contains('Армянский').click();
    cy.get('#languageSwitcher > [href="#"]').should('contain', 'Hy');
  });

    it('Change language to Arabic', () => {
    cy.get('#languageSwitcher').click();
    cy.get('#languageSwitcher > .wpml-ls-statics-shortcode_actions > ul > .wpml-ls-item-ar > .wpml-ls-link > .wpml-ls-display').contains('Арабский').click();
    cy.get('#languageSwitcher > [href="#"]').should('contain', 'Ar');
  });

    it('Change language to Belarusian', () => {
    cy.get('#languageSwitcher').click();
    cy.get('#languageSwitcher > .wpml-ls-statics-shortcode_actions > ul > .wpml-ls-item-bel > .wpml-ls-link > .wpml-ls-display').contains('Беларусский').click();
    cy.get('#languageSwitcher > [href="#"]').should('contain', 'Bel');
  });

    it('Change language to Greek', () => {
    cy.get('#languageSwitcher').click();
    cy.get('#languageSwitcher > .wpml-ls-statics-shortcode_actions > ul > .wpml-ls-item-el > .wpml-ls-link > .wpml-ls-display').contains('Греческий').click();
    cy.get('#languageSwitcher > [href="#"]').should('contain', 'El');
  });

    it('Change language to Hindi', () => {
    cy.get('#languageSwitcher').click();
    cy.get('#languageSwitcher > .wpml-ls-statics-shortcode_actions > ul > .wpml-ls-item-hi > .wpml-ls-link > .wpml-ls-display').contains('Хинди').click();
    cy.get('#languageSwitcher > [href="#"]').should('contain', 'Hi');
  });

    it('Change language to Korean', () => {
    cy.get('#languageSwitcher').click();
    cy.get('#languageSwitcher > .wpml-ls-statics-shortcode_actions > ul > .wpml-ls-item-ko > .wpml-ls-link > .wpml-ls-display').contains('Корейский').click();
    cy.get('#languageSwitcher > [href="#"]').should('contain', 'Ko');
  });

    it('Change language to Mongolian', () => {
    cy.get('#languageSwitcher').click();
    cy.get('#languageSwitcher > .wpml-ls-statics-shortcode_actions > ul > .wpml-ls-item-mn > .wpml-ls-link > .wpml-ls-display').contains('Монгольский').click();
    cy.get('#languageSwitcher > [href="#"]').should('contain', 'Mn');
  });

       
    it('Change language to Polish', () => {
    cy.get('#languageSwitcher').click();
    cy.get('#languageSwitcher > .wpml-ls-statics-shortcode_actions > ul > .wpml-ls-item-pl > .wpml-ls-link > .wpml-ls-display').contains('Польский').click();
    cy.get('#languageSwitcher > [href="#"]').should('contain', 'Pl');
  }); 


    it('Change language to Romanian', () => {
    cy.get('#languageSwitcher').click();
    cy.get('#languageSwitcher > .wpml-ls-statics-shortcode_actions > ul > .wpml-ls-item-ro > .wpml-ls-link > .wpml-ls-display', {timeout: 7000}).contains('Румынский').click({timeout: 12000});
    cy.get('#languageSwitcher > [href="#"]').should('contain', 'Ro');
  });

    it('Проверка поиска с результатами', () => {
    cy.get('#searchOpen > a > svg').click();  // нажать на лупу
    cy.get('#searchForm > .field__wrapper > #s').click();  // нажать на инпут
    cy.get('#searchForm > .field__wrapper > #s').type('новости');  // ввести в инпут "новости"
    cy.get('#searchForm > .field__wrapper > #s').type('{enter}');   // нажать энтер
    cy.get('.breadcrumbs__current').contains('Результаты поиска по запросу "новости"').should('be.visible');
    cy.get('.breadcrumbs__current').should('contain', 'Результаты поиска по запросу "новости"');
    cy.get('.search-results').should('exist');
  });


    it('Проверка поиска', () => {
    cy.get('#searchOpen > a > svg').click();  // нажать на лупу
    cy.get('#searchClose').should('be.visible');  // нажать на инпут
    cy.get('#searchForm').should('be.visible'); 
    cy.get('#searchForm > .field__wrapper > #s').click();  // нажать на инпут
    cy.get('#searchForm > .field__wrapper > #s').type('новости');  // ввести в инпут "новости"
    cy.get('#globalSearchClose').should('be.visible');
    cy.get('#globalSearchClose').click();
    cy.get('#searchForm > .field__wrapper > #s').should('contain', '');

    cy.get('#searchForm > .field__wrapper > #s').click();  // нажать на инпут
    cy.get('#searchForm > .field__wrapper > #s').type('gjfj');  // ввести в инпут 
    cy.get('#searchForm > .field__wrapper > #s').type('{enter}');   // нажать энтер
    cy.get('.not-found__title').contains('Ничего не найдено').should('be.visible');
    cy.get('.not-found__title').should('contain', 'Ничего не найдено')

  });

});
